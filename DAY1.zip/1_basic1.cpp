// 5 page

// 함수 오버로딩 : 인자의 갯수나 타입이 다르면 동일이름의 함수를 여러개 만들수 있다.

int square(int a)
{
	return a * a;
}

double square(double a)
{
	return a * a;
}

int main()
{
}
