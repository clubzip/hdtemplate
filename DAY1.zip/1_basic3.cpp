#include <iostream>

// template instantiation(템플릿 인스턴스화)
// => 템플릿(틀) 로 부터 실제 "함수/클래스"를 만드는 과정

template<typename T>
T square(T a)
{

	return a * a;
}

int main()
{
	square<int>(3);			
	square<double>(3.3);
	square(3);
}

