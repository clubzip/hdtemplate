#include <iostream>

template<typename T>
T square(T a)
{
	return a * a;
}

int main()
{
	printf("%p\n", &square);	// ?

	auto p1 = &square;			// ?
}

