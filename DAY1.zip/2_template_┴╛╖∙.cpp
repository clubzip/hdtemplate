#include <iostream>
#include <list>
#include <queue>
#include <vector>
#include <funtional>

// template 의 종류 - 8 page

// 1. function template
template<typename T> T square(T a)
{
	return a * a;
}

// 2. class template
template<typename T> class Vector
{
	T* buff;
};

// 3. variable template
template<typename T>
constexpr T pi = static_cast<T>(3.141692);

double d = pi<double>;	
float f = pi<float>;	


// 4. using template 
template<typename T>
using MyList = std::list<T>;

MyList<int> s; 

