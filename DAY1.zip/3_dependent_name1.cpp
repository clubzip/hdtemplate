// 77 page
struct Object
{
	using type = int;

	static constexpr int value = 10;
};
int p1;

template<typename T>
void foo(T obj)
{
	// 아래 코드에서 * 연산자의 의미를 생각해 보세요
	Object::value * p1;
	Object::type  * p1;
	
}


int main()
{
	Object obj;
	foo(obj);
}