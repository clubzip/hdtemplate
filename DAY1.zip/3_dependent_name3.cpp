template<typename T>
struct Object
{
	using type = int;

	template<typename U>
	static void mf() {	}
};
template<typename T>
void foo()
{
	// 1. typename 
	T::type t;

	Object<int>::type t1;
	Object<T>::type t2;	
	
	
	// 2. template
	Object<int>::mf<double>();	

	Object<T>::mf<double>();	
}

int main()
{
	foo<int>();
}