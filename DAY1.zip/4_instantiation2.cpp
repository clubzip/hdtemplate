#include <iostream>

// explicit instantiation 

template<typename T>
T square(T a)
{
	return a * a;
}

int main()
{

}

