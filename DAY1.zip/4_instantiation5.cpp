#include <tuple>

// convenient function template

int main()
{
	std::tuple<int, double, char> t1(10, 3.3, 'A');

}