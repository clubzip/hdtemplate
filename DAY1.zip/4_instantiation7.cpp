#include <iostream>
#include <functional>
#include <type_traits> // std::type_identity

// 27page. identity

template<typename T> void foo(T a)
{
}

template<typename T> void goo(T a)
{
}

int main()
{
	foo(10);		// ok
	foo<int>(10);	// ok

	goo(10);	  // ok
	goo<int>(10); // ok
}