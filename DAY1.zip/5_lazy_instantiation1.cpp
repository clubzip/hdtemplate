// 32 page, lazy instantiation

class Object
{
	int value;
public:
	void mf()
	{
		*value = 10; // ?
	}
};

int main()
{
	Object obj;
}
