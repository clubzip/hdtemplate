#include <iostream>
#include "fname.h"

// 규칙 3. 
template<typename T> void f3(T&& arg)
{
	std::cout << _FNAME_ << std::endl;
}

int main()
{
	int  n = 10;
	int& r = n;
	const int  c = 10;
	const int& cr = c;

	f3(3);
	f3(n);
	f3(c);
	f3(r);
	f3(cr);

}