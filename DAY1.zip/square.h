// square.h
template<typename T> T square(T a);