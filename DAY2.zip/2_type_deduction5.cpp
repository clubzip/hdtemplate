template<typename T>
void fn(T arg)
{

}

int main()
{
	const int c = 10;
	fn(c);

	auto  a1 = c;
	auto& a2 = c;


	int n = 10;
	auto&& a3 = 3;
	auto&& a4 = n;

}