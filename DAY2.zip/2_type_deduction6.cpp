// 2번 복사해오세요
#include <iostream>
#include "fname.h"

// 핵심 : template 과 배열 인자

template<typename T> void f1(T arg)
{
	std::cout << _FNAME_ << std::endl;
}

template<typename T> void f2(T& arg)
{
	std::cout << _FNAME_ << std::endl;
}

int main()
{
	int x[3] = { 1,2,3 };

	f1(x);	// T = ?		arg = ?
	f2(x);	// T = ?		arg = ?
}
