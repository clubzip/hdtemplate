// 2번 복사해오세요
#include <iostream>
#include "fname.h"

// 핵심 : template 과 배열 인자

template<typename T>
void f1(T a, T b)
{
	std::cout << _FNAME_ << std::endl;
}
template<typename T>
void f2(T& a, T& b)
{
	std::cout << _FNAME_ << std::endl;
}

int main()
{

	f1("orange", "apple");	// ?

	f2("orange", "apple");	// ?

	f2("orange", "banana"); // ?

}
