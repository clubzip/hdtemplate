#include <iostream>

// Vector vs Vector<T>

template<typename T>
class Vector
{
	T* ptr;
	std::size_t  size;
public:
	Vector(std::size_t sz) : size(sz)
	{
		ptr = new T[sz];
	}
	~Vector() { delete[] ptr; }

	T& operator[](std::size_t idx) { return ptr[idx];}

	// 핵심 3. 다음중 맞는 것은 ?
//	void swap(Vector&    v) {}	// 1. ?
//	void swap(Vector<T>& v) {}  // 2. ?
};

// 핵심 2.
// void fn(? v) {}

int main()
{
	// 핵심 1.
	Vector v1(10);		// ?
	Vector<int> v2(10);	// ?


//	fn(v2);
}
