#include <iostream>

// class template 에서 멤버 함수의 선언과 구현의 분리
template<typename T>
class Vector
{
	T* ptr;
	std::size_t  size;
public:
	Vector(std::size_t sz) : size(sz)
	{
		ptr = new T[sz];
	}

	~Vector() 
	{ 
		delete[] ptr; 
	}

	T& operator[](std::size_t idx) 
	{
		return ptr[idx]; 
	}
};

int main()
{

}
