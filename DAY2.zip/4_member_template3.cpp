// coercion by member template

class Point
{
	int x, y;
public:
	Point(int a, int b) : x(a), y(b) {}
};

int main()
{
	Point p1(1, 2);
	Point p2 = p1;
}
