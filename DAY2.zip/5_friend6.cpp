// 5_friend6.cpp

// 클래스와 friend 관계
//====================
// 

struct Object1
{
	friend void f1();
};
void f1() {}

