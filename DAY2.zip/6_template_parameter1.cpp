// 92 page

// 템플릿 파라미터는 3가지 종류가 있습니다.
// 1. type
// 2. non-type
// 3. template

template<typename T> class list 
{
};
	
template<typename T,					
	     int N,							
	     template<typename> class C>	
class Object
{
};

int main()
{
	list      s1;
	list<int> s2;

	Object< ? , ? , ? > obj;
}
