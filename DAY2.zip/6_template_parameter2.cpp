#include <iostream>
#include <stack>
#include <vector>
#include <list>
#include <deque>

// STL 의 stack 은 실제로 아래 처럼 구현되어 있습니다.

template<typename T, typename C = std::deque<T> > 
class stack
{
	C c;
public:
	void push(const T& value) 	{ c.push_back(value); }
	void pop()            		{ c.pop_back(); }
	T&   top()            		{ return c.back(); }
};

int main()
{
	std::stack<int> s1;

	s1.push(10); 

}

