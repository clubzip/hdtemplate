#include <iostream>

template<typename T, int N> 
struct Object
{
	T buff[N];	
};
int main()
{
	Object<int, 10> obj1;	// ok. 

	int n = 10;
	Object<int,  n> obj1;	//  ?
							


}


