#include <iostream>

// 핵심 : 문법 연습

template<typename T, typename U> struct Object
{
	static void fn() { std::cout << "T, U" << std::endl; }
};

int main()
{
	Object<char, double>::fn();	  // T, U
	Object<char*, double*>::fn(); // T*, U*	
	Object<short*, double>::fn(); // T*, U
	Object<float,  float>::fn();  // T, T
	Object<int,    float>::fn();  // int, U
	Object<int, short>::fn();	  // int, short

}
