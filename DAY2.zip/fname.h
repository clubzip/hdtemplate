// fname.h
#pragma once

#include <string>
#include <sstream>

#if defined(__GNUC__)
#	define _FNAME_ __PRETTY_FUNCTION__
#elif defined(_MSC_VER)
#	define _FNAME_ __FUNCSIG__
#else
#	define _FNAME_ __func__
#endif


#ifdef __has_include
#	if __has_include(<source_location>)    
#		include <source_location>

std::string function_name(std::source_location loc = std::source_location::current())
{
	std::string name = loc.function_name();

	std::istringstream iss(name);
	std::ostringstream oss;
	std::string s;

	while (iss >> s)
	{
		// "foo(void)" => "foo()" in cl compiler
		if (s.size() > 6 && s.substr(s.size() - 6, 6) == "(void)") // foo(void)
		{
			s.replace(s.size() - 6, 6, "()");
			s.shrink_to_fit();
		}
		if (s != "__cdecl" && s != "__stdcall" && s != "__fastcall" && s != "__thiscall" && s != "thiscall")
			oss << s << " ";
	}
	return oss.str();
}

#	endif
#endif

