#include <iostream>



template<typename T> 
void fn(const T& arg)
{
	// 현재 T는 int, int* 
	if (  ? )
		std::cout << "pointer" << std::endl;
	else
		std::cout << "not pointer" << std::endl;
}

int main()
{
	int n = 0;
	fn(n);
	fn(&n);
}
