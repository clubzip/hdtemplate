#include <iostream>

// is_pointer 구현을 참고해서 is_array 만들어 보세요

template<typename T> 
void fn(T& arg)
{	
	if (is_array<T>::value)
		std::cout << "array" << std::endl;
	else
		std::cout << "not array" << std::endl;
}
int main()
{
	int n = 0;
	int x[3] = {1,2,3};

	fn(n);	// 0(false)
	fn(x);	// 1(true) 나와야 합니다.
	
}
