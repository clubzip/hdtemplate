#include <iostream>
#include <type_traits>

// 변형된 타입을 얻는 traits 를 만드는 방법

template<typename T> void foo(T a)
{
	remove_pointer<int*>::type n1; // int

	std::cout << typeid(n1).name() << std::endl;
}

int main()
{
	int n = 0;
	foo(&n);
}
