#include <iostream>

int main()
{
	std::remove_pointer<int***>::type n; // int**

}
