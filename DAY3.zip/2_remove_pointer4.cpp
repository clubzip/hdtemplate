#include <iostream>
// traits 기술 정리

// 핵심 1. 헤더 파일은 "<type_traits>", C++11
#include <type_traits>


template<typename T>
void fn(const T& arg)
{
	// 핵심 2. 타입의 특성 조사
	bool b1 = std::is_pointer<T>::value;


	// 핵심 3. 변형 타입얻기
	typename std::remove_pointer<T>::type n1;

}

int main()
{
	int n = 0;
	fn(&n);
}
