// is_pointer1.cpp 복사

