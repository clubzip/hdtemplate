#include <iostream>

// SFINAE 가 적용되는 3가지 경우
// 1. 함수의 리턴 타입
// 2. 함수의 인자
// 3. 템플릿 인자

void fn(...) { std::cout << "..." << std::endl; }

template<typename T> 
typename T::type fn(T a) { }


int main()
{
	fn(3);
}
