// 6_enable_if1.cpp

template<bool, typename T = void > struct enable_if
{
	using type = T;  // C++11 이후 스타일
};

template<typename T> struct enable_if<false, T> 
{
};

int main()
{
	// 아래 코드에서 n1, n2, n3 의 타입은 ?
	enable_if<true, int>::type  n1; 
	enable_if<true>::type       n2; 
									
	enable_if<false, int>::type n3; 
}
