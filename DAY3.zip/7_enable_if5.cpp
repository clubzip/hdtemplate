// printv 복사
