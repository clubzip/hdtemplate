#include <iostream>
#include <string>
#include <string_view>	

// 함수 인자로 읽기 전용 문자열을 받으려고 합니다.

void f1(std::string s) {}      

void f2(const std::string& s) {} 


void f3(std::string_view sv) {}

int main()
{
	std::string s1 = "to be or not to be";

	f1(s1);
	f2(s1);
	f3(s1);


	// 
	f2("to be or not to be");
	f3("to be or not to be");
}

