#include <iostream>
#include <string>
#include <vector>
#include <string_view>
#include <ranges>

int main()
{
	std::vector<int> v = { 1,2,3,4,5 };

	// 1. 반복자를 꺼내는 2가지 방법
	auto it1 = v.begin();
	auto it2 = std::begin(v);


	// 2. rvalue 와 반복자
	auto p1 = std::begin( std::string("to be or not to be") );

	std::string s1 = "to be or not to be";
	auto p2 = std::begin(std::string_view(s1));

}
