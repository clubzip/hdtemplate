#include <iostream>

template<typename T> 
void foo(T arg)
{

}

int main()
{
	foo(1);
	foo(1, 2);
	foo(1, 2, 3);
}
