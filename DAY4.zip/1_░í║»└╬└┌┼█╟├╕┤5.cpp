#include <iostream>
#include <tuple>

template<typename ... Types> void foo(Types ... args)
{
	// args 에 있는 모든 요소를 꺼내고 싶다면
	// 
	// args 안에 있는 2번째 값을 얻고 싶다.
	// => 한번에 할수 있는 방법은 없습니다.

	// 아래 3개 방법 중에 한개를 사용해야 합니다.
	// 1. pack expansion		- C++11
	// 2. recursive 와 유사한 기술 - C++11
	// 3. fold expression - C++17


}

int main()
{
	foo(1, 2, 3);
}

