#include <iostream>

// 방법 2. recursive 유사 코드

template<typename ... Types>
void foo(Types ... args)
{
	std::cout << valu
}

int main()
{
	foo(1, 3.4, 'A'); 
}





