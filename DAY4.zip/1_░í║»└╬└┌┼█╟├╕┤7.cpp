#include <iostream>

int main()
{
	// C 언어의 printf 는 안전하지 않습니다.
	printf("%d, %d\n", 1);			// 인자 갯수 부족
	printf("%d, %d\n", 1, 2, 3);	// 인자 갯수 초과
}
