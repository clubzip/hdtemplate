#include <iostream>
#include <mutex>

void f1(int n) {}
void f2(int n, double d) {}


int main()
{
	f1(10); 
}
