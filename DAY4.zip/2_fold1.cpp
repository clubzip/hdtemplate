#include <iostream>

// fold expression ( C++17 )
// => parameter pack 안에 모든 요소에 대해서 이항 연산을 수행하는 표현식

template<typename ... Types>
auto sum(Types... args)
{
	// args 안의 모든 요소에 대해 합을 구하고 싶다.	
	// args    : 1 , 2 , 3 , 4 , 5 , 2.4 , 4.3
	// 원하는것 : 1 + 2 + 3 + 4 + 5 + 2.4 + 4.3
}


int main()
{
	auto ret = sum(1, 2, 3, 4, 5, 2.4, 4.3);

	std::cout << ret << std::endl;
}
