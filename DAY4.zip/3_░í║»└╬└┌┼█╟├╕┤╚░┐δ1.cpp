#include <iostream>

// 함수의 반환 타입 구하기
 
// 핵심 1. 변수(또는 함수)선언문에서 이름만 제거하면 "타입" 이 됩니다.

int f(int a, double b) { return 0; }


template<typename T> void foo(T& a) 
{
	// T : int(int, double) 입니다.
	typename result<T>::type n; 

	std::cout << typeid(n).name() << std::endl;  
}

int main()
{
	foo(f);
}
