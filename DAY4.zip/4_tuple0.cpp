#include <tuple>
#include <vector>
#include <iostream>

int main()
{
	// vector : "동일한 타입" 을 여러개 보관
	std::vector<int> v{1,2,3};
	
	// pair : "서로 다른 타입" 을 "2개" 보관
	std::pair<int, double> p1(1, 3.4);

	// pair 에 2개 이상 보관도 가능합니다.

}
