#include <iostream>
using namespace std;

struct Base
{
	int value = 10;
};
struct Derived : public Base
{
	// 기반 클래스와 동일이름의 멤버 데이타를 추가해도 됩니다.
	int value = 20;
};
int main()
{
	Derived d;

	cout << d.value << endl; // 10 ? 20
}
