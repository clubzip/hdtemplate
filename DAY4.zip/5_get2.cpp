#include <iostream>
#include "tuple.h"

int main()
{
//	tuple<			   char>				 // 2번째 기반, 'A'보관
//	tuple<     double, char>				 // 1번째 기반 , 3.4보관
	tuple<int, double, char> t(1, 3.4, 'A'); // t 자신은     1보관

	std::cout << t.value << std::endl; // ?
}
