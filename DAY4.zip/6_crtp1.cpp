#include <iostream>

class Base
{
public:
	void fn()
	{
		// 여기서 파생 클래스의 이름을 알수 있을까 ?
	}
};

class Derived : public Base
{

};

int main()
{
	Derived  d;
	d.fn();
}





