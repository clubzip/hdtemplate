#include <iostream>

// 라이브러리 내부
class Window
{
public:
	void event_loop() 
	{		
		Click();				
	}
	void Click()     { std::cout << "Window Click" << std::endl; }
};

// 아래 클래스가 라이브러리 사용자 코드.
class MainWindow : public Window 
{
public:
	void Click() { std::cout << "MainWindow Click" << std::endl; }
};

int main()
{
	MainWindow w;
	w.event_loop();
}
