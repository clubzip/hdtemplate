// thin template 
// 3번 복사