#include <iostream>
#include <vector>
#include <type_traits>


template<typename T> void check(T& c)
{
	// T 가 포인터 타입 인지 알고 싶다.
	// => C++11 type traits 사용
	bool b = std::is_pointer_v<T>;
}

int main()
{
	int n = 0;
	std::vector<int> v = { 1,2,3 };
	int x[3] = { 1,2,3 };

	check(n);	
	check(v);	
	check(x);   
}
