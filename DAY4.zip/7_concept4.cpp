#include <iostream>
#include <type_traits>
#include <vector>
#include <iterator>
#include <concepts>
#include <ranges>

template<typename T>
concept container = requires(T & c)
{
	std::ranges::begin(c);
	std::ranges::end(c);
};

template<typename T> requires container<T>
void fn(const T& c)
{
	std::cout << "container" << std::endl;
}


int main()
{
	std::vector<int> v = { 1,2,3 };
}
