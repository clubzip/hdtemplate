#include <iostream>
#include <algorithm>
#include <concepts>
#include <vector>


int main()
{
	std::vector<int> v = { 1,2,3,4,5,6,7,8,9,10 };
	
	// find    : 주어진 구간에서 값 검색
	// find_if : 주어진 구간에서 조건 검색(마지막 인자로 호출가능한 객체(callable object) 전달)

	auto p1 = std::find(   std::begin(v), std::end(v), 3);
	auto p2 = std::find_if(std::begin(v), std::end(v), [](int a) { return a % 3 == 0; } );


}
